const BASE = 'https://generativelanguage.googleapis.com/';
const SYSTEM_PROMPT =
  'Hỗ trợ đối chiếu bài tập luyện tập. Trả đáp án ngắn gọn theo số câu kèm một bước kiểm chứng ngắn. ' +
  'Trình bày công thức toán học bằng ký tự Unicode dễ đọc (ví dụ: x², √x, ∫, π, ≤, ≥, ≠, →), ' +
  'không dùng cú pháp LaTeX thô như $ hoặc \\frac. Nếu thiếu dữ kiện, hãy nói rõ.';

let state = {
  key: '',
  version: '',
  models: [],
  active: '',
  busy: false
};

const $ = (id) => document.getElementById(id);

function showView(name) {
  document.querySelectorAll('.view').forEach((v) => v.classList.remove('active'));
  $(`view-${name}`).classList.add('active');
}

function setBusy(flag) {
  state.busy = flag;
  document.querySelectorAll('#view-login .btn, #view-home .btn').forEach((b) => {
    b.disabled = flag;
  });
}

async function apiRequest(key, version, path, payload = null) {
  const res = await fetch(`${BASE}${version}/${path}`, {
    method: payload ? 'POST' : 'GET',
    headers: {
      'x-goog-api-key': key,
      'Content-Type': 'application/json'
    },
    body: payload ? JSON.stringify(payload) : null
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const detail = data?.error?.message || res.statusText;
    throw new Error(`HTTP ${res.status}: ${detail}`.replaceAll(key, '[KEY]'));
  }
  return data;
}

function rankModels(models) {
  return [...new Set(models)].sort((a, b) => {
    const score = (n) => {
      const stable = !/(preview|experimental|-exp)/.test(n) ? 1 : 0;
      const flash = n.includes('flash') ? 1 : 0;
      const lite = n.includes('lite') ? 1 : 0;
      const m = n.match(/gemini-(\d+)(?:\.(\d+))?/);
      const maj = m ? parseInt(m[1] || '0', 10) : 0;
      const min = m ? parseInt(m[2] || '0', 10) : 0;
      return [stable, flash, lite, maj, min];
    };
    const sa = score(a);
    const sb = score(b);
    for (let i = 0; i < sa.length; i++) {
      if (sa[i] !== sb[i]) return sb[i] - sa[i];
    }
    return 0;
  });
}

async function discover(key) {
  for (const version of ['v1beta', 'v1']) {
    let models = [];
    let page = '';
    try {
      do {
        const q = new URLSearchParams({ pageSize: '100' });
        if (page) q.set('pageToken', page);
        const data = await apiRequest(key, version, `models?${q.toString()}`);
        for (const m of data.models || []) {
          const name = m.name || '';
          const methods = m.supportedGenerationMethods || [];
          const excluded = ['embedding', 'tts', 'audio', 'live', 'image', 'robotics', 'computer-use', 'research'];
          if (
            name.startsWith('models/gemini-') &&
            methods.includes('generateContent') &&
            !excluded.some((x) => name.includes(x))
          ) {
            models.push(name);
          }
        }
        page = data.nextPageToken || '';
      } while (page);
    } catch (e) {
      if (e.message.startsWith('HTTP 404') && version === 'v1beta') continue;
      throw e;
    }
    if (models.length) {
      return { version, models: rankModels(models) };
    }
  }
  throw new Error('Không tìm thấy model Gemini phù hợp.');
}

async function generate(key, version, model, parts, check = false) {
  const payload = { contents: [{ parts }] };
  if (check) payload.generationConfig = { maxOutputTokens: 128 };
  const data = await apiRequest(key, version, `${model}:generateContent`, payload);
  const text = (data.candidates || [])
    .flatMap((c) => c.content?.parts || [])
    .filter((p) => p.text && !p.thought)
    .map((p) => p.text)
    .join('\n')
    .trim();
  if (!text) {
    throw new Error('Model không trả về văn bản.');
  }
  return text;
}

async function runSolver(parts = null) {
  if (state.busy) return;
  const token = $('api-input').value.trim();
  const isCheck = parts === null;
  const statusEl = isCheck ? $('status-login') : $('status-home');

  if (!token) {
    statusEl.textContent = 'Vui lòng nhập hoặc dán API Key.';
    return;
  }

  setBusy(true);
  statusEl.textContent = isCheck ? 'Đang kiểm tra kết nối...' : 'Đang giải bài...';

  try {
    const info = isCheck ? await discover(token) : { version: state.version, models: state.models };
    const content = isCheck ? [{ text: 'Reply OK.' }] : [{ text: SYSTEM_PROMPT }, ...parts];
    const order = [...info.models];
    if (!isCheck && state.active && order.includes(state.active)) {
      order.splice(order.indexOf(state.active), 1);
      order.unshift(state.active);
    }

    const errors = [];
    for (const model of order.slice(0, 2)) {
      statusEl.textContent = `Đang gọi ${model.split('/').pop()}...`;
      try {
        const answer = await generate(token, info.version, model, content, isCheck);
        state.key = token;
        state.version = info.version;
        state.models = info.models;
        state.active = model;
        $('model-badge').textContent = model.split('/').pop();

        if (isCheck) {
          await chrome.storage.local.set({ gemini_api_key: token });
          $('status-home').textContent = 'Đã kết nối thành công!';
          showView('home');
        } else {
          $('result-box').value = answer;
          statusEl.textContent = 'Hoàn tất!';
        }
        return;
      } catch (err) {
        errors.push(err.message);
        if (err.message.startsWith('HTTP 401') || err.message.startsWith('HTTP 403')) break;
      }
    }
    throw new Error(errors.join(' | '));
  } catch (err) {
    statusEl.textContent = err.message;
  } finally {
    setBusy(false);
  }
}

function blobToPart(blob) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const maxDim = 2200;
      let { width, height } = img;
      if (width > maxDim || height > maxDim) {
        const ratio = Math.min(maxDim / width, maxDim / height);
        width = Math.round(width * ratio);
        height = Math.round(height * ratio);
      }
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      canvas.getContext('2d').drawImage(img, 0, 0, width, height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
      resolve({
        inlineData: {
          mimeType: 'image/jpeg',
          data: dataUrl.split(',')[1]
        }
      });
    };
    img.onerror = () => reject(new Error('Không thể đọc dữ liệu ảnh.'));
    img.src = URL.createObjectURL(blob);
  });
}

function cropDataUrl(dataUrl, rect) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const dpr = rect.dpr || 1;
      const sx = Math.round(rect.x * dpr);
      const sy = Math.round(rect.y * dpr);
      const sw = Math.round(rect.w * dpr);
      const sh = Math.round(rect.h * dpr);
      const canvas = document.createElement('canvas');
      canvas.width = sw;
      canvas.height = sh;
      canvas.getContext('2d').drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh);
      canvas.toBlob((blob) => {
        if (!blob) return reject(new Error('Lỗi cắt vùng ảnh.'));
        blobToPart(blob).then(resolve).catch(reject);
      }, 'image/jpeg', 0.92);
    };
    img.onerror = () => reject(new Error('Lỗi xử lý ảnh chụp tab.'));
    img.src = dataUrl;
  });
}

document.addEventListener('DOMContentLoaded', async () => {
  const saved = await chrome.storage.local.get(['gemini_api_key', 'pending_crop']);
  if (saved.gemini_api_key) {
    $('api-input').value = saved.gemini_api_key;
  }

  if (saved.pending_crop) {
    await chrome.storage.local.remove('pending_crop');
    const { dataUrl, rect, key, version, models, active } = saved.pending_crop;
    state = { ...state, key, version, models, active };
    $('api-input').value = key;
    $('model-badge').textContent = (active || '').split('/').pop() || 'Gemini';
    showView('home');
    try {
      const part = await cropDataUrl(dataUrl, rect);
      await runSolver([part]);
    } catch (e) {
      $('status-home').textContent = e.message;
    }
    return;
  }

  let val = 0;
  const steps = [
    [25, 'Đang tải giao diện Extension...'],
    [55, 'Đang nạp bộ nhớ cấu hình...'],
    [85, 'Đang chuẩn bị kết nối Gemini API...'],
    [100, 'Hệ thống đã sẵn sàng!']
  ];
  const timer = setInterval(() => {
    val += 4;
    if (val <= 100) {
      $('progress-fill').style.width = `${val}%`;
      const step = steps.find(([t]) => val <= t) || steps[3];
      $('load-msg').textContent = `${step[1]} (${val}%)`;
    } else {
      clearInterval(timer);
      const btn = $('btn-start');
      btn.disabled = false;
      btn.classList.remove('btn-disabled');
      btn.classList.add('btn-accent');
      btn.textContent = 'BẮT ĐẦU →';
    }
  }, 25);

  $('btn-start').addEventListener('click', () => showView('login'));

  $('btn-paste-api').addEventListener('click', async () => {
    try {
      const text = (await navigator.clipboard.readText()).trim();
      if (text) {
        $('api-input').value = text;
        $('status-login').textContent = 'Đã dán API Key từ Clipboard.';
      }
    } catch {
      $('status-login').textContent = 'Hãy nhấn Ctrl+V trực tiếp vào ô nhập Key.';
    }
  });

  $('btn-toggle-key').addEventListener('click', () => {
    const inp = $('api-input');
    const hidden = inp.type === 'password';
    inp.type = hidden ? 'text' : 'password';
    $('btn-toggle-key').textContent = hidden ? 'Ẩn Key' : 'Hiện Key';
  });

  $('btn-connect').addEventListener('click', () => runSolver(null));

  $('btn-solve-text').addEventListener('click', () => {
    const txt = $('text-input').value.trim();
    if (!txt) {
      $('status-home').textContent = 'Hãy nhập hoặc dán đề bài trước.';
      return;
    }
    runSolver([{ text: txt }]);
  });

  $('btn-paste-smart').addEventListener('click', async () => {
    try {
      const items = await navigator.clipboard.read();
      for (const item of items) {
        const imgType = item.types.find((t) => t.startsWith('image/'));
        if (imgType) {
          const blob = await item.getType(imgType);
          const part = await blobToPart(blob);
          await runSolver([part]);
          return;
        }
      }
      const text = await navigator.clipboard.readText();
      if (text) $('text-input').value = text;
    } catch {
      $('status-home').textContent = 'Nhấn Ctrl+V trực tiếp để dán ảnh hoặc văn bản.';
    }
  });

  document.addEventListener('paste', async (e) => {
    if (!$('view-home').classList.contains('active') || state.busy) return;
    const files = e.clipboardData?.files;
    if (files && files.length > 0 && files[0].type.startsWith('image/')) {
      e.preventDefault();
      const part = await blobToPart(files[0]);
      await runSolver([part]);
    }
  });

  $('file-input').addEventListener('change', async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 10 * 1024 * 1024) {
      $('status-home').textContent = 'Ảnh vượt quá 10 MB.';
      return;
    }
    const part = await blobToPart(file);
    await runSolver([part]);
    e.target.value = '';
  });

  $('btn-snip').addEventListener('click', async () => {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id || tab.url.startsWith('chrome://') || tab.url.startsWith('edge://')) {
        $('status-home').textContent = 'Không thể chụp trang hệ thống trình duyệt.';
        return;
      }
      const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
      await chrome.storage.local.set({
        snip_session: {
          dataUrl,
          key: state.key,
          version: state.version,
          models: state.models,
          active: state.active
        }
      });
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content.js']
      });
      window.close();
    } catch (err) {
      $('status-home').textContent = 'Lỗi chụp trang: ' + err.message;
    }
  });

  $('btn-copy').addEventListener('click', async () => {
    const val = $('result-box').value.trim();
    if (!val) return;
    await navigator.clipboard.writeText(val);
    $('status-home').textContent = 'Đã sao chép kết quả.';
  });

  $('btn-change-api').addEventListener('click', () => showView('login'));
});

(() => {
  if (document.getElementById('thanhdevhub-snip-overlay')) return;

  const overlay = document.createElement('div');
  overlay.id = 'thanhdevhub-snip-overlay';
  Object.assign(overlay.style, {
    position: 'fixed',
    inset: '0',
    background: 'rgba(0, 0, 0, 0.35)',
    zIndex: '2147483647',
    cursor: 'crosshair',
    userSelect: 'none'
  });

  const hint = document.createElement('div');
  hint.textContent = 'Kéo chuột chọn vùng bài tập • Nhấn Esc để hủy (ThanhDevHub)';
  Object.assign(hint.style, {
    position: 'fixed',
    top: '16px',
    left: '20px',
    color: '#fff',
    background: 'rgba(16, 16, 16, 0.85)',
    padding: '8px 14px',
    borderRadius: '6px',
    fontFamily: 'Segoe UI, sans-serif',
    fontSize: '14px',
    fontWeight: '700',
    pointerEvents: 'none'
  });

  const box = document.createElement('div');
  Object.assign(box.style, {
    position: 'fixed',
    border: '2px solid #00d9ff',
    background: 'rgba(0, 217, 255, 0.12)',
    display: 'none',
    pointerEvents: 'none'
  });

  overlay.appendChild(hint);
  overlay.appendChild(box);
  document.documentElement.appendChild(overlay);

  let startX = 0;
  let startY = 0;
  let dragging = false;

  const cleanup = () => {
    window.removeEventListener('keydown', onKey);
    overlay.remove();
  };

  const onKey = (e) => {
    if (e.key === 'Escape') cleanup();
  };
  window.addEventListener('keydown', onKey);

  overlay.addEventListener('mousedown', (e) => {
    dragging = true;
    startX = e.clientX;
    startY = e.clientY;
    Object.assign(box.style, {
      left: `${startX}px`,
      top: `${startY}px`,
      width: '0px',
      height: '0px',
      display: 'block'
    });
  });

  overlay.addEventListener('mousemove', (e) => {
    if (!dragging) return;
    const x = Math.min(startX, e.clientX);
    const y = Math.min(startY, e.clientY);
    const w = Math.abs(e.clientX - startX);
    const h = Math.abs(e.clientY - startY);
    Object.assign(box.style, {
      left: `${x}px`,
      top: `${y}px`,
      width: `${w}px`,
      height: `${h}px`
    });
  });

  overlay.addEventListener('mouseup', async (e) => {
    if (!dragging) return;
    dragging = false;
    const x = Math.min(startX, e.clientX);
    const y = Math.min(startY, e.clientY);
    const w = Math.abs(e.clientX - startX);
    const h = Math.abs(e.clientY - startY);
    cleanup();

    if (w < 10 || h < 10) return;

    const { snip_session } = await chrome.storage.local.get('snip_session');
    if (snip_session) {
      await chrome.storage.local.remove('snip_session');
      await chrome.storage.local.set({
        pending_crop: {
          ...snip_session,
          rect: { x, y, w, h, dpr: window.devicePixelRatio || 1 }
        }
      });
      alert('Đã chụp vùng bài tập! Nhấn lại vào biểu tượng Extension Solver Pro V8 trên thanh công cụ để xem kết quả.');
    }
  });
})();
